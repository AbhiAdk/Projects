package com.example.baby_buy.Adapter;

import android.view.View;

public interface RecyclerViewItemClickListener {
    public void onItemClick(View view, int position);
}
