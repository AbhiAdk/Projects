<?php
$captcha_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recaptcha_secret = '6LeVImMlAAAAAK4IfbbOhewgC1jrJQaGk3keK4Sc';
    $recaptcha_response = $_POST['g-recaptcha-response'];
    $remote_ip = $_SERVER['REMOTE_ADDR'];

    // Send a POST request to the reCAPTCHA verification API endpoint
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array(
        'secret' => $recaptcha_secret,
        'response' => $recaptcha_response,
        'remoteip' => $remote_ip
    )));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    // Parse the JSON response
    $result = json_decode($response, true);

    if ($result['success']) {
        // Perform desired action on successful reCAPTCHA validation
    } else {
        $captcha_error = "Invalid reCAPTCHA.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>reCAPTCHA v2 Example</title>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script>
        function formSubmit() {
            const captchaError = document.getElementById("captcha-error");
            const response = grecaptcha.getResponse();

            if (response.length === 0) {
                captchaError.innerHTML = "Invalid captcha. Please try again.";
            } else {
                document.getElementById("my-form").submit();
            }
        }
    </script>
</head>
<body>
    <form id="my-form" method="POST">

        <div class="g-recaptcha" data-sitekey="6LeVImMlAAAAANPmN-YL3pEKloZTSeHirno7qUoc"></div>
        <button type="button" onclick="formSubmit();">Submit</button>
        <p id="captcha-error" style="color: red;">
        <?php echo $captcha_error; ?></p>

    </form>
</body>
</html>
