

REQUIREMENTS
--------------------------------------------------------------------------------
- Visual Studio Code (Version: 1.77.1)
- XAMPP server (lv3.2.2)
- Operating System: Windows 10 pro 
	Version	22H2
	Installed on	‎11/‎10/‎2022
	OS build	19045.2728
	Experience	Windows Feature Experience Pack 120.2212.4190.0


INSTALLATION
--------------------------------------------------------------------------------
1. Install Visual Studio Code from https://code.visualstudio.com/
2. Install XAMPP server  from https://www.apachefriends.org/index.html
3. Clone or download the project repository to your local machine.
4. Place the project folder in the XAMPP "htdocs" directory.
5. Start the XAMPP server and open phpMyAdmin in your browser (usually at http://localhost/phpmyadmin).
6. Create a new database and import the provided SQL file to set up the required tables.
8. Open the project folder in Visual Studio Code and start coding.

