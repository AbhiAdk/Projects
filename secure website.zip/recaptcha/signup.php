

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

</head>
<body>
<form action="connection.php" method="post">
    <!-- Your form fields go here -->
    <div class="g-recaptcha" data-sitekey="6Ld-hy4lAAAAAEYzL-2YXh254749vZ9BVuvuftj_"></div>
    <button type="submit" name="submit">Submit</button>
</form>

</body>
</html>